#!/opt/homebrew/Caskroom/miniforge/base/envs/tf_38/bin/python

from IPC2cpp import *
from dnnModel import *
from utility import *

import torch
import signal

count=0

# SIGNAL for write status
def sigusr1_rec(sig, frame):
  global count
  writePath=".tmp/dump2/py"
  fp=open(writePath, "w")
  fp.write("%d" %count)
  fp.close()
  excLogger("Signal to write Status")

if __name__=="__main__":
  shrKey=3274
  
  shr=shrMemory(shrKey)
  excLogger("ShrMemory Linked")
  
  init=pthCheck()
  if init==0:
    dnn=XPSDNN(2048, 80)
  else:
    dnn=torch.load("pth/XPSdnn%6d.pth" %init)
  
  count=init*validSpan
  excLogger("Initialize Programm from %d" %count)
  
  optim=torch.optim.Adam(dnn.parameters(), lr=1e-3)
  loss1=torch.nn.MSELoss()
  loss2=highPassLoss
  
  signal.signal(signal.SIGUSR1, sigusr1_rec)
  
  while(shr.waitInfo()):
    count+=1
    
    orig=dnn.train()
    optim.zero_grad()
    
    try:
      raw=shr.readRaw()
    except:
      excLogger("shared Read Raw Error")
      exit(1)
    
    try:
      info=shr.readInfo()
    except:
      excLogger("shared Read Info Error")
      exit(1)
    
    try:
      cOut, qOut=dnn(raw)
    except:
      excLogger("DNN model Training Error")
      exit(1)
    
    try:
      cTar, qTar=translate(info)
    except:
      excLogger("info Translate Error: #%d [%s]" %(count, info))
      exit(1)
    
    try:
      l1=loss1(cTar, cOut)
      l1.backward(retain_graph=True)
    except:
      excLogger("L1 Error")
      exit(1)
    
    try:
      l2=loss2(qTar, qOut)
      l2.backward()
    except:
      excLogger("L2 Error")
      exit(1)
    
    try:
      optim.step()
    except:
      excLogger("Backpropagation Error")
      exit(1)
    
    if(count%validSpan==0):
      torch.save(dnn, "pth/XPSdnn%6d.pth" %(count//validSpan))
      # validation process
      try:
        sum1, sum2=validation(dnn, loss1, loss2)
      except:
        excLogger("Validation Process Error")
        exit(1)
      
      lossListAppend(sum1, sum2)
    
    try:
      shr.writeInfo()
    except:
      excLogger("ShrMemory Write Error")
      exit(1)
  
  try:
    torch.save(dnn, "./shut/ExitShut%d.pth" %count)
  except:
    excLogger("ShrMemory Exit Error")
    exit(1)
  
  excLogger("Terminate Process without Trouble Founded")
